// Tiny synth sound engine. No audio files, everything generated. Muted state persists.
let ctx: AudioContext | null = null;
let muted = localStorage.getItem("vb.muted") === "1";

export const isMuted = () => muted;
export function setMuted(m: boolean) {
  muted = m;
  localStorage.setItem("vb.muted", m ? "1" : "0");
}

function ac(): AudioContext | null {
  if (muted) return null;
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctx.state === "suspended") ctx.resume();
    return ctx.state === "running" || ctx.state === "suspended" ? ctx : null;
  } catch {
    return null;
  }
}

function tone(freq: number, dur: number, opts: { type?: OscillatorType; gain?: number; delay?: number; slideTo?: number } = {}) {
  const c = ac();
  if (!c) return;
  const t0 = c.currentTime + (opts.delay ?? 0);
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = opts.type ?? "sine";
  o.frequency.setValueAtTime(freq, t0);
  if (opts.slideTo) o.frequency.exponentialRampToValueAtTime(opts.slideTo, t0 + dur);
  const vol = opts.gain ?? 0.05;
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(vol, t0 + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g).connect(c.destination);
  o.start(t0);
  o.stop(t0 + dur + 0.02);
}

export const S = {
  click: () => tone(660, 0.03, { gain: 0.022 }),
  cash: () => { tone(880, 0.09, { type: "triangle", gain: 0.05 }); tone(1318, 0.14, { type: "triangle", gain: 0.05, delay: 0.07 }); },
  payday: () => { tone(659, 0.1, { type: "triangle", gain: 0.05 }); tone(880, 0.1, { type: "triangle", gain: 0.05, delay: 0.09 }); tone(1318, 0.2, { type: "triangle", gain: 0.06, delay: 0.18 }); },
  thud: () => tone(140, 0.22, { type: "sine", gain: 0.07, slideTo: 55 }),
  fanfare: () => {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.16, { type: "square", gain: 0.03, delay: i * 0.09 }));
    tone(1046, 0.4, { type: "triangle", gain: 0.05, delay: 0.4 });
  },
  streak: () => { tone(784, 0.07, { type: "square", gain: 0.035 }); tone(988, 0.07, { type: "square", gain: 0.035, delay: 0.06 }); tone(1175, 0.12, { type: "square", gain: 0.04, delay: 0.12 }); },
};
