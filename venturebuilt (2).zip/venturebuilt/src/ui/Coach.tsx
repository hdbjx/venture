import React from "react";
import type { GameState } from "../sim/types";
import { laborPool } from "../sim/engine";
import { FINANCE } from "../config/balance";

type Advice = { icon: string; text: string; tone: "bad" | "warn" | "good"; tab?: string };

// Rule-based coach: turns the numbers into 1-3 plain sentences about what actually matters right now.
export function getAdvice(g: GameState): Advice[] {
  const out: Advice[] = [];
  const capacity = laborPool(g).reduce((a, w) => a + w.hours, 0);
  const backlog = g.jobs
    .filter((j) => j.status === "scheduled" || j.status === "inProgress")
    .reduce((a, j) => a + (j.hours - j.progress), 0);
  const offers = g.jobs.filter((j) => j.status === "offered").length;
  const payroll = g.employees.reduce((a, e) => a + e.wage * FINANCE.payrollEveryDays, 0);
  const avgMorale = g.employees.length ? g.employees.reduce((a, e) => a + e.morale, 0) / g.employees.length : 100;
  const worstGear = Math.min(...g.equipment.map((e) => e.condition), 100);
  const totalMarketing = Object.values(g.marketing).reduce((a, b) => a + (b || 0), 0);
  const avgPrice = Object.values(g.prices).reduce((a, b) => a + b, 0) / Math.max(1, Object.values(g.prices).length);

  if (g.cash < 0) out.push({ icon: "🚨", text: "You're in the red. Stop spending, finish jobs, or take a loan before morale collapses.", tone: "bad", tab: "Finances" });
  else if (g.employees.length && g.cash < payroll) out.push({ icon: "⚠️", text: `Payroll is $${payroll.toLocaleString()} on Friday and you can't cover it yet. Finish jobs or borrow.`, tone: "bad", tab: "Finances" });

  if (capacity > 0 && backlog > capacity * 1.6) out.push({ icon: "🧯", text: "You're overbooked — crews are rushing and quality is slipping. Pass on new jobs or hire help.", tone: "bad", tab: "Team" });
  else if (g.employees.length >= 1 && backlog < capacity * 0.4 && offers === 0) out.push({ icon: "🪑", text: "Your crew is sitting idle but still getting paid. Push marketing to bring in leads.", tone: "warn", tab: "Marketing" });

  if (worstGear < 40) out.push({ icon: "🔧", text: "Your gear is beat up — worn equipment drags down every job's quality. Maintain it.", tone: "warn", tab: "Equipment" });
  if (g.employees.length && avgMorale < 40) out.push({ icon: "😤", text: "Crew morale is low. Raises, lighter workload, or a manager will stop people from quitting.", tone: "warn", tab: "Team" });
  if (g.reputation < 2.6) out.push({ icon: "📉", text: "Reputation is hurting you. Take fewer jobs and do them well — quality is the way back.", tone: "bad" });
  if (totalMarketing === 0 && offers < 2 && g.day > 5) out.push({ icon: "📣", text: "No marketing is running, so leads will dry up. Even $10/day on flyers keeps the phone ringing.", tone: "warn", tab: "Marketing" });
  if (g.reputation >= 3.8 && avgPrice <= 1.05) out.push({ icon: "💰", text: "Your reputation supports higher prices. Nudge them up — premium customers will still book.", tone: "good" });
  if (g.ownerFatigue > 70) out.push({ icon: "🥱", text: "You're exhausted — burning out costs you 2 working hours a day. Time to hire.", tone: "warn", tab: "Team" });

  if (out.length === 0) out.push({ icon: "✅", text: "Business is steady. To grow: more marketing, another hire, or better equipment.", tone: "good" });
  return out.slice(0, 3);
}

export function CoachCard({ g, setTab }: { g: GameState; setTab?: (t: string) => void }) {
  const advice = getAdvice(g);
  return (
    <div className="card p-3.5 mb-4 border-l-2 border-l-mint-500">
      <div className="label mb-1.5">What matters right now</div>
      <div className="space-y-1.5">
        {advice.map((a, i) => (
          <div key={i} className="flex items-start gap-2 text-sm">
            <span>{a.icon}</span>
            <span className={a.tone === "bad" ? "text-coral-400" : a.tone === "warn" ? "text-gold-400" : "text-ink-200"}>
              {a.text}
              {a.tab && setTab && (
                <button className="ml-1.5 text-sky2-400 underline underline-offset-2 hover:text-sky2-300" onClick={() => setTab(a.tab!)}>
                  {a.tab} →
                </button>
              )}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// Four big plain-language health tiles replacing the raw stat grid.
export function HealthTiles({ g }: { g: GameState }) {
  const capacity = laborPool(g).reduce((a, w) => a + w.hours, 0);
  const backlog = g.jobs.filter((j) => j.status === "scheduled" || j.status === "inProgress").reduce((a, j) => a + (j.hours - j.progress), 0);
  const payroll = g.employees.reduce((a, e) => a + e.wage * FINANCE.payrollEveryDays, 0);
  const avgMorale = g.employees.length ? g.employees.reduce((a, e) => a + e.morale, 0) / g.employees.length : 100;

  const money = g.cash < 0 ? ["Trouble", "text-coral-400"] : g.cash < Math.max(400, payroll) ? ["Tight", "text-gold-400"] : ["Good", "text-mint-400"];
  const load = backlog > capacity * 1.6 ? ["Overbooked", "text-coral-400"] : backlog > capacity * 0.9 ? ["Busy", "text-gold-400"] : backlog > 0 ? ["On it", "text-mint-400"] : ["Quiet", "text-gold-400"];
  const crewWord = !g.employees.length ? ["Just you", "text-sky2-400"] : avgMorale >= 70 ? ["Happy", "text-mint-400"] : avgMorale >= 45 ? ["Okay", "text-gold-400"] : ["Unhappy", "text-coral-400"];
  const repWord = g.reputation >= 4.2 ? ["Loved", "text-mint-400"] : g.reputation >= 3.4 ? ["Trusted", "text-mint-400"] : g.reputation >= 2.8 ? ["Mixed", "text-gold-400"] : ["Shaky", "text-coral-400"];

  const Tile = ({ label, big, word, color, sub }: { label: string; big: string; word: string; color: string; sub: string }) => (
    <div className="card p-3">
      <div className="label">{label}</div>
      <div className="num text-lg font-bold leading-tight mt-0.5">{big}</div>
      <div className={`text-xs font-semibold ${color}`}>{word}</div>
      <div className="text-[11px] text-ink-500 mt-0.5">{sub}</div>
    </div>
  );

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      <Tile label="Money" big={`$${Math.round(g.cash).toLocaleString()}`} word={money[0]} color={money[1]}
        sub={g.employees.length ? `payroll $${payroll.toLocaleString()} Fri` : "no payroll yet"} />
      <Tile label="Workload" big={`${Math.round(backlog)}h`} word={load[0]} color={load[1]}
        sub={`crew does ~${Math.round(capacity)}h/day`} />
      <Tile label="Crew" big={g.employees.length ? `${g.employees.length + 1} people` : "Solo"} word={crewWord[0]} color={crewWord[1]}
        sub={g.employees.length ? `morale ${Math.round(avgMorale)}%` : g.ownerFatigue > 60 ? "you're tired" : "you've got this"} />
      <Tile label="Reputation" big={`${g.reputation.toFixed(1)}★`} word={repWord[0]} color={repWord[1]}
        sub={`${g.reviews.length} reviews`} />
    </div>
  );
}
